"""
Version information for PyGraphviz, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.2'
__revision__ = None
__date__ = 'Sat Aug  3 09:57:44 2013'

